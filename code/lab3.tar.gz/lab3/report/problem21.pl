!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!                              MATH 578 LAB1
! Author: Wenqiang Feng
! Date  : Aug.31, 2015
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
PROGRAM lab3
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
!
REAL(KIND=r8) :: a, b, tend, dtfactor,dtout, D, Area
REAL(KIND=r8) :: dx, dtEXPL, dt, time, tout
INTEGER:: MM, M, i, nsteps, MaxSteps
INTEGER:: ierror
REAL(KIND=r8), DIMENSION(:), ALLOCATABLE:: x, U, F

! read data from the file
NAMELIST/inputdata/ a, b, MM, tend, dtfactor, dtout, D
!
OPEN(UNIT=75,FILE='inputdata.dat',STATUS='OLD',ACTION='READ',IOSTAT=ierror)
IF(ierror/=0) THEN
PRINT *,'Error opening input file problemdata.dat. Program stop.'
STOP
END IF
READ(75,NML=inputdata)
CLOSE(75)
!
WRITE(*,*) 'Input values:', 'a=', a, 'b=', b
!
M = (b-a)*MM
dx = 1.0_r8/(MM*1.0_r8)
dtEXPL = dx*dx/(2.0_r8*D)
dt = dtfactor*dtEXPL
MaxSteps=INT(tend/dt)+1
nsteps = 0
time =0.0_r8
tout = dtout
PRINT *, 'MaxSteps=', MaxSteps

!
PRINT *, 'dt=', dt
!
ALLOCATE(x(0:M+1), U(0:M+1), F(0:M+1))

PRINT *, 'M=', M


!-------------------- Generate the mesh--------------------------------------!
!
CALL mesh(a, b, dx, M, x)
!PRINT *, 'x=', x
!
!-------------------- Initialization-----------------------------------------!
!
CALL init(x,U)
CALL OutPut(nsteps)
CALL TrapzRule( M, dx, U, Area)
PRINT *, 'Initial Area=', Area
!
!-------------------- Begin timestepping-------------------------------------!
DO nsteps = 1, MaxSteps
time= nsteps*dt
CALL flux(D, M, U, x, F, time)
CALL pde(dt, MM, M, U, F, b, D)
IF (time >= tout) THEN
!PRINT *, time
CALL OutPut(nsteps)
tout=tout+dtout
CALL comparison(x, U, time, D)
END IF
end DO
!
PRINT *, ' DONE, exiting at time= ', time, 'after ', nsteps, ' steps'
CALL TrapzRule( M, dx, U, Area)
PRINT *, 'Final Area=', Area

DEALLOCATE(x, U, F)
!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
CONTAINS
!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE mesh(a, b, dx, M, x)
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
REAL(KIND=r8), INTENT(IN):: a, b, dx
INTEGER, INTENT(IN):: M
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: x
INTEGER:: i

x(0) = a
x(1) = a + 0.5_r8*dx
do i = 2, M
x(i) = x(1) + (i-1)*dx
end do
x(M+1) = b

END SUBROUTINE mesh

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE init(x,U)
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: x
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: U

INTEGER :: i

DO i = 0, SIZE(x,1)-1
U(i)=0.0_r8
END DO

END SUBROUTINE init

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE flux(D, M, U, x, F, time)
IMPLICIT NONE
REAL(KIND=r8), INTENT(IN):: D, time
INTEGER, INTENT(IN)::  M
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: x
REAL(KIND=r8), DIMENSION(0:), INTENT(INOUT):: U
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: F
INTEGER :: i

! Update Left BC before calculate Left Flux
U(0) = 1._r8
F(1) = -D*(U(1)-U(0))/(x(1)-x(0))
!
DO i = 2, M
F(i) = -D*(U(i)-U(i-1))/(x(i)-x(i-1))
END DO
!
! Update Right BC before calcualte Right Flux
U(M+1) = 1._r8 - DERF(b / (2._r8*SQRT(D*time)))
F(M+1) = -D*(U(M+1)-U(M))/(x(M+1)-x(M))

END SUBROUTINE

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE pde(dt, MM, M, U, F, b, D)
IMPLICIT NONE
REAL(KIND=r8), INTENT(IN)::dt,b,D
INTEGER, INTENT(IN)::  MM, M
REAL(KIND=r8), DIMENSION(0:), INTENT(IN OUT):: U
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: F
INTEGER :: i

DO i = 1, M
U(i) = U(i)+dt*MM*(F(i)-F(i+1))
END DO

END SUBROUTINE

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE TrapzRule( M, dx, U, Area)
IMPLICIT NONE
INTEGER, INTENT(IN)::  M
REAL(KIND=r8), INTENT(IN):: dx
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: U
REAL(KIND=r8), INTENT(OUT):: Area

Area = ( U(0) - U(1) - U(M) + U(M+1) )/4

DO i = 1,M
Area = Area + U(i)
ENDDO
Area = Area * dx

END SUBROUTINE

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE OutPut(k)
IMPLICIT NONE
!
INTEGER, INTENT(IN):: k
!
CHARACTER(LEN=13):: file_name
CHARACTER(LEN=4):: string
INTEGER:: i, j
!INTEGER:: ierror

!
WRITE(string,'(i4)') k
DO i = 1, 4
IF(string(i:i)==' ') string(i:i) = '0'
END DO
!print *, string
file_name = 'OUT/m'//string//'.dat'

OPEN(UNIT=9, FILE=file_name, STATUS='REPLACE', ACTION='WRITE')
WRITE(9,'(A1,2(A24,1x))') '#', 'x','U'
DO j = 0, SIZE(x,1)-1
WRITE(9,'(2(f25.12,1x))') x(j), U(j)
END DO
CLOSE(9)

END SUBROUTINE OutPut

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SUBROUTINE comparison(x, U, time, D)
IMPLICIT NONE
!
REAL(KIND=r8), INTENT(IN):: D, time
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: x, U
!
INTEGER:: i
REAL(KIND=r8), DIMENSION(:), ALLOCATABLE :: Uexact
CHARACTER(LEN=18):: file_name
REAL(KIND=r8), DIMENSION(0:SIZE(U)-1) :: error

ALLOCATE(Uexact(0:SIZE(x,1)-1))

file_name = 'OUT/comparison.dat'
OPEN(UNIT=101, FILE=file_name, STATUS='REPLACE', ACTION='WRITE')
WRITE(101,'(A1,4(A24,1x))') '#', 'x','U','Uexact', 'Error'

DO i = 0, SIZE(x,1)-1
Uexact(i) = 1._r8 - DERF(x(i) / (2._r8*SQRT(D*time)))
error(i)=ABS(U(i)-Uexact(i))
WRITE(101,'(4(f25.12,1x))') x(i), U(i), Uexact(i),error(i)
END DO
PRINT *, 'The maximum |error| over all i=',MAXVAL(error)
CLOSE(101)

END SUBROUTINE comparison

END PROGRAM lab3
