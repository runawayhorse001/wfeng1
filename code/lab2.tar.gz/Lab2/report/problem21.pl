!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!                              MATH 578 LAB2
! Author: Wenqiang Feng
! Date  : Aug.31, 2015
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
PROGRAM lab1
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
!
REAL(KIND=r8) :: a, b, tend, dtfactor,dtout, D, Area
REAL(KIND=r8) :: dx, dtEXPL, dt, time, tout
INTEGER:: MM, M, i, nsteps, MaxSteps
INTEGER:: ierror
REAL(KIND=r8), DIMENSION(:), ALLOCATABLE:: x, U, F

! read data from the file
NAMELIST/inputdata/ a, b, MM, tend, dtfactor, dtout, D
!
OPEN(UNIT=75,FILE='inputdata.dat',STATUS='OLD',ACTION='READ',IOSTAT=ierror)
IF(ierror/=0) THEN
PRINT *,'Error opening input file problemdata.dat. Program stop.'
STOP
END IF
READ(75,NML=inputdata)
CLOSE(75)
!
WRITE(*,*) 'Input values:', 'a=', a, 'b=', b
!
M = (b-a)*MM
dx = 1.0_r8/(MM*1.0_r8)
dtEXPL = dx*dx/(2.0_r8*D)
dt = dtfactor*dtEXPL
MaxSteps=INT(tend/dt)+1
nsteps = 0
time =0.0_r8
tout = dtout
PRINT *, 'MaxSteps=', MaxSteps

!
PRINT *, 'dt=', dt
!
ALLOCATE(x(0:M+1), U(0:M+1), F(0:M+1))

PRINT *, 'M=', M


!-------------------- Generate the mesh--------------------------------------!
!
CALL mesh(a, b, dx, M, x)
!PRINT *, 'x=', x
!
!-------------------- Initialization-----------------------------------------!
!
CALL init(x,U)
CALL OutPut(nsteps)
CALL TrapzRule( M, dx, U, Area)
PRINT *, 'Initial Area=', Area
!
!-------------------- Begin timestepping-------------------------------------!
DO nsteps = 1, MaxSteps
CALL flux(D, M, U, x, F)
CALL pde(dt, MM, M, U, F)
time= nsteps*dt
IF (time >= tout) THEN
!PRINT *, time
CALL OutPut(nsteps)
tout=tout+dtout
END IF
end DO
!
PRINT *, ' DONE, exiting at time= ', time, 'after ', nsteps, ' steps'
CALL TrapzRule( M, dx, U, Area)
PRINT *, 'Final Area=', Area

DEALLOCATE(x, U, F)
!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
CONTAINS
!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SUBROUTINE mesh(a, b, dx, M, x)
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
REAL(KIND=r8), INTENT(IN):: a, b, dx
INTEGER, INTENT(IN):: M
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: x
INTEGER:: i

x(0) = a
x(1) = a + 0.5_r8*dx
do i = 2, M
x(i) = x(1) + (i-1)*dx
end do
x(M+1) = b

END SUBROUTINE mesh
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SUBROUTINE init(x,U)
IMPLICIT NONE
INTEGER, PARAMETER:: r8 = SELECTED_REAL_KIND(15,307)
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: x
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: U

INTEGER :: i

DO i = 0, SIZE(x,1)-1
IF (x(i).GE.1.0_r8 .AND. x(i).LE.2.0_r8) THEN
U(i)=5.0_r8
ELSE
U(i)=0.0_r8
END IF
END DO

END SUBROUTINE init
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SUBROUTINE flux(D, M, U, x, F)
IMPLICIT NONE
REAL(KIND=r8), INTENT(IN):: D
INTEGER, INTENT(IN)::  M
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: x, U
REAL(KIND=r8), DIMENSION(0:), INTENT(OUT):: F
INTEGER :: i

!For Dirichlet BC
!F(1) = -D*(U(1)-U(0))/(x(1)-x(0))
!DO i = 2, M
!F(i) = -D*(U(i)-U(i-1))/(x(i)-x(i-1))
!END DO
!F(M+1) = -D*(U(M+1)-U(M))/(x(M+1)-x(M))
!
!For Neumann BC (impermeable)
F(1) = 0.0
DO i = 2, M
F(i) = -D*(U(i)-U(i-1))/(x(i)-x(i-1))
END DO
F(M+1) = 0.0
END SUBROUTINE
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SUBROUTINE pde(dt, MM, M, U, F)
IMPLICIT NONE
REAL(KIND=r8), INTENT(IN)::dt
INTEGER, INTENT(IN)::  MM, M
REAL(KIND=r8), DIMENSION(0:), INTENT(IN OUT):: U
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: F
INTEGER :: i

DO i = 1, M
U(i) = U(i)+dt*MM*(F(i)-F(i+1))
END DO
U(0)=U(1)
U(M+1) = U(M)

END SUBROUTINE
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SUBROUTINE TrapzRule( M, dx, U, Area)
IMPLICIT NONE
INTEGER, INTENT(IN)::  M
REAL(KIND=r8), INTENT(IN):: dx
REAL(KIND=r8), DIMENSION(0:), INTENT(IN):: U
REAL(KIND=r8), INTENT(OUT):: Area

Area = ( U(0) - U(1) - U(M) + U(M+1) )/4

DO i = 1,M
Area = Area + U(i)
ENDDO
Area = Area * dx

END SUBROUTINE
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!
SUBROUTINE OutPut(k)
IMPLICIT NONE
!
INTEGER, INTENT(IN):: k
!
CHARACTER(LEN=13):: file_name
CHARACTER(LEN=4):: string
INTEGER:: i, j
!INTEGER:: ierror

!
WRITE(string,'(i4)') k
DO i = 1, 4
IF(string(i:i)==' ') string(i:i) = '0'
END DO
!print *, string
file_name = 'OUT/m'//string//'.dat'
!
OPEN(UNIT=9, FILE=file_name, STATUS='REPLACE', ACTION='WRITE')
WRITE(9,'(A1,2(A24,1x))') '#', 'x','U'
DO j = 0, SIZE(x,1)-1
WRITE(9,'(2(f25.12,1x))') x(j), U(j)
END DO
CLOSE(9)
!
END SUBROUTINE OutPut


END PROGRAM lab1
